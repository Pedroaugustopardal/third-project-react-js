# Front-end com React.JS
Front-end feito em JavaScript.
Projeto feito IFRJ Campus Paulo de Frotin
Este Front-end aceita novos usuários por seu nome e email.
Sendo ID gerado automaticamente e fica invísel.
Integrantes: Mauro José Mourão Pardal, Gabriel Machado Correia Pinto e Jéssica Jesus de Oliveira Pereira

